'use strict';

module.exports = function(Coffeeshop) {

};
